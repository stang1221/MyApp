import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList; //never used
import java.util.HashMap;
import java.util.Scanner;  // Import the Scanner class


public class Adventure {
    private static HashMap<Integer, Room> roomsMap = new HashMap<>();
    private static int currentRoomId;


    /**
     * method: displayRooms
     * purpose: Displays all the rooms in the roomsMap
     */

    private static void displayRooms() {
        for (Room room : roomsMap.values()) {
            System.out.println(room);
            System.out.println("----");
        }
    }


    public static void main(String[] args) {
        try {
            loadRoomsFromFile("room.txt");
            displayRooms(); // Fixed: Display the rooms
            playGame();
        } catch (IOException e) {
            System.out.println("Error reading room data file: " + e.getMessage());
        }


     //   System.out.println(roomsMap);

    }

    private static void loadRoomsFromFile(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;


        while ((line = reader.readLine()) != null) {
            if (line.equals("----")) {
                int roomId = Integer.parseInt(reader.readLine());
                String roomName = reader.readLine();
                String roomDescription = reader.readLine();
                reader.readLine(); // Skip the "false" line
                reader.readLine(); // Skip the "false" line


//                ArrayList<String> directions = new ArrayList<>();
//                String directionLine = reader.readLine();
//                while (!directionLine.isEmpty()) {
//                    directions.add(directionLine);
//                    directionLine = reader.readLine();
//                }
                String directionLine = reader.readLine();
                HashMap<String,Integer> directions = new HashMap<>();

                String[] elements = directionLine.split(",\\s*");

                for (String element : elements){
                    String[] keyValue = element.split(":\\s*");

                    if (keyValue.length ==2){
                        String key = keyValue[0].trim();
                        int value = Integer.parseInt(keyValue[1].trim());
                        directions.put(key, value);
                    }
                }


                boolean visited = Boolean.parseBoolean(reader.readLine()); // Fix: Read and assign the visited value


                Room room = new Room(roomId, roomName, roomDescription, directions);
                room.setVisited(visited); // Fix: Set the visited value

                roomsMap.put(roomId, room);
//                System.out.println(directions);
            }
        }

        reader.close();

    }


    private static void playGame() {
        currentRoomId = 1; // Start the game in Room 1 (Living Room)

        Room currentRoom = roomsMap.get(currentRoomId); // Get the initial current room

        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to the Adventure Game!");
        System.out.println("You are currently in the " + currentRoom.getName());
        System.out.println(currentRoom.getDescription());

        while (true) {
            System.out.println("Enter a direction to move (N, S, E, W):");
            String direct = input.nextLine().toLowerCase();

            if (direct.equals("quit")) { // Fix: Check direct instead of input
                System.out.println("Thank you for playing!");
                break;
            }

            if (direct.equals("n") || direct.equals("s") || direct.equals("e") || direct.equals("w")) {
                move(direct);
            } else {
                System.out.println("Invalid direction. Please try again.");
            }

        }
        input.close();
    }


    private static void move(String direction) {
        Room currentRoom = roomsMap.get(currentRoomId);

        switch (direction) {
            case "n":
                if (currentRoom.getDirections().containsKey("North") && currentRoom.getDirections().get("North") != 0) {
                    currentRoomId = currentRoom.getDirections().get("North");
                } else {
                    System.out.println("There is no exit in that direction. Please choose another direction.");
                }
                break;
            case "s":
                if (currentRoom.getDirections().containsKey("South") && currentRoom.getDirections().get("South") != 0) {
                    currentRoomId = currentRoom.getDirections().get("South");
                } else {
                    System.out.println("There is no exit in that direction. Please choose another direction.");
                }
                break;
            case "e":
                if (currentRoom.getDirections().containsKey("East") && currentRoom.getDirections().get("East") != 0) {
                    currentRoomId = currentRoom.getDirections().get("East");
                } else {
                    System.out.println("There is no exit in that direction. Please choose another direction.");
                }
                break;
            case "w":
                if (currentRoom.getDirections().containsKey("West") && currentRoom.getDirections().get("West") != 0) {
                    currentRoomId = currentRoom.getDirections().get("West");
                } else {
                    System.out.println("There is no exit in that direction. Please choose another direction.");
                }
                break;
        }
        currentRoom = roomsMap.get(currentRoomId);
        currentRoom.setVisited(true); // Mark the current room as visited
        System.out.println("You are now in the " + currentRoom.getName());
        System.out.println(currentRoom.getDescription());
    }
}
