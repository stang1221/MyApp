import java.util.ArrayList; //never used
import java.util.HashMap;
/*
 * Class: Room
 * Purpose: Sets up two constructors for creating Room objects. This class
 * will be used to create room objects from the scanner that reads the room.txt file.
 * There is one default constructor with example data in it, and one multi parameter
 * constructor used for inputting room information. Each variable has a getter and setter, and
 * the ToString has been overridden to display some that looks like this:
 *
 * ID= 1, name= test
 * Description:
 * test
 * exits:
 * You can go [WEST, EAST]
 *
 */

public class Room {

    //Integer for rooms Id number
    private int Id;
    //String for rooms name
    private String name;
    //String for rooms description (NOTE: may have to make this a CharArray at some point, idk)
    private String description;
    //ArrayList for all the directions that a room can have
    private HashMap<String, Integer> directions;
    //Marking for visited
    private boolean visited;
    private HashMap<String, Integer> exits;


    //Default Constructor
    public Room() {
        this.Id = 0;
        this.name = "Example Room";
        this.description = "An example room for a default constructor";
        this.directions = new HashMap<>();
        this.visited = false;
        this.exits = new HashMap<>();
    }

    //Multi-Parameter Constructor
    public Room(int Id, String name, String description, HashMap<String, Integer> directions) {
        this.Id = Id;
        this.name = name;
        this.description = description;
        this.directions = directions;
    }

    //Getters
    public int getId() {
        return Id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        StringBuilder descriptionBuilder = new StringBuilder();
        descriptionBuilder.append(description);
        descriptionBuilder.append("\n");


        return descriptionBuilder.toString();
    }

    public HashMap<String,Integer> getDirections() {
        return directions;
    }

    //this never used.
    public HashMap<String, Integer> getExits() {
        return exits;
    }


    //never used
    public void addExit(String direction, int roomId) {
        exits.put(direction, roomId);
    }

    //Setters
    public void setId(int id) {
        Id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDirections(HashMap<String, Integer> directions) {
        this.directions = directions;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    //toString
    @Override
    public String toString() {
        return "ID= " + getId() + ", name= " + getName() + "\n" + "Description:" + "\n" + getDescription() + "\n" + "exits:" + "\n" + "You can go " + getDirections().toString() + "\n";
    }
}


